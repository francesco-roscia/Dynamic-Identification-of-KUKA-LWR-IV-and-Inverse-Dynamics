d3 = 0.4;
d5 = 0.39;

alpha = [pi/2 -pi/2 -pi/2 pi/2 pi/2 -pi/2 0];
alphamod = [0; pi/2; -pi/2; -pi/2; pi/2; pi/2; -pi/2];

a = [0 0 0 0 0 0 0];
d = [0 0 0.4 0 0.39 0 0];

