function tau = modDH_finalloop_NE(i, M)

    tau = M(:,i)'*[0;0;1];
    
end

